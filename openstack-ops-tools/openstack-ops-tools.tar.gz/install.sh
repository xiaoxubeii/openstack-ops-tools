#!/usr/bin/env bash
source base.sh
run conf/install.sh
